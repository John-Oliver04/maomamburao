<?php if(Auth::user()->hasRole('admin')): ?>
    <div class="">


        <!-- Page Wrapper -->
        <div id="wrapper">

            <!-- Sidebar -->
            <ul class="navbar-nav bg-gradient-success sidebar sidebar-dark accordion " id="accordionSidebar">

                <!-- Sidebar - Brand -->
                <a class="sidebar-brand d-flex align-items-center justify-content-center" href="">
                    <div class="sidebar-brand-icon rotate-n-15">
                        <img src="<?php echo e(asset('logo1.png')); ?>" width="60px" alt="">
                    </div>
                    <div class="mx-3 sidebar-brand-text">MAO<sup>Admin</sup></div>
                </a>

                <!-- Divider -->
                <hr class="my-0 sidebar-divider">

                <!-- Nav Item - Dashboard -->
                <li class="nav-item active">
                    <button onclick="dashboardFunc()"  class="nav-link" >
                        <i class="fas fa-fw fa-tachometer-alt"></i>
                        Dashboard
                    </button>
                </li>

                <!-- Divider -->
                <hr class="sidebar-divider">

                <!-- Heading -->
                <div class="sidebar-heading">
                    Menus
                </div>

                <!-- Nav Item - Pages Collapse Menu -->
                <li class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                        aria-expanded="true" aria-controls="collapseTwo">
                        <i class="fas fa-fw fa-folder"></i>
                        <span>Pages</span>
                    </a>
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                        <div class="py-2 bg-white rounded collapse-inner">
                            <h6 class="collapse-header">Web Pages:</h6>
                            <button onclick="aboutFunc()"   class="text-left collapse-item w-100" >About</button>
                            <button onclick="servicesFunc()" class="text-left collapse-item w-100" >Services</button>
                        </div>
                    </div>
                </li>

                <!-- Nav Item - Utilities Collapse Menu -->
                

                <!-- Divider -->
                <hr class="sidebar-divider d-none d-md-block">

                <!-- Sidebar Toggler (Sidebar) -->
                <div class="text-center d-none d-md-inline">
                    <button class="border-0 rounded-circle" id="sidebarToggle"></button>
                </div>



            </ul>
            <!-- End of Sidebar -->

            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">

                <!-- Main Content -->
                <div id="content">

                    <!-- Topbar -->
                    <nav class="mb-4 bg-white shadow navbar navbar-expand navbar-light topbar static-top">

                        <!-- Sidebar Toggle (Topbar) -->
                        <button id="sidebarToggleTop" class="mr-3 btn btn-link d-md-none rounded-circle">
                            <i class="fa fa-bars"></i>
                        </button>

                        <!-- Topbar Search -->
                        

                        <!-- Topbar Navbar -->
                        <ul class="ml-auto navbar-nav">

                            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                            <li class="nav-item dropdown no-arrow d-sm-none">
                                <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-search fa-fw"></i>
                                </a>
                                <!-- Dropdown - Messages -->
                                <div class="p-3 shadow dropdown-menu dropdown-menu-right animated--grow-in"
                                    aria-labelledby="searchDropdown">
                                    <form class="mr-auto form-inline w-100 navbar-search">
                                        <div class="input-group">
                                            <input type="text" class="border-0 form-control bg-light small"
                                                placeholder="Search for..." aria-label="Search"
                                                aria-describedby="basic-addon2">
                                            <div class="input-group-append">
                                                <button class="btn btn-primary" type="button">
                                                    <i class="fas fa-search fa-sm"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </li>


                            <?php
                                $count = App\Models\ContactRequest::count();
                            ?>
                            <!-- Nav Item - Messages -->
                            <li class="mx-1 nav-item dropdown no-arrow">
                                <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-envelope fa-fw"></i>
                                    <!-- Counter - Messages -->
                                    <span class="badge badge-danger badge-counter">


                                        <?php echo e($count); ?>


                                    </span>
                                </a>
                                <!-- Dropdown - Messages -->
                                <div class="shadow dropdown-list dropdown-menu dropdown-menu-right animated--grow-in"
                                    aria-labelledby="messagesDropdown">
                                    <h6 class="dropdown-header">
                                        Message Center
                                    </h6>
                                    <?php
                                        $messages = App\Models\ContactRequest::all();
                                    ?>
                                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="mr-3 dropdown-list-image">
                                                <i class="text-gray-500 fas fa-2x fa-solid fa-user-tie"></i>

                                                <div class="status-indicator bg-success"></div>
                                            </div>
                                            <div class="font-weight-bold">
                                                <div class="text-truncate"><?php echo e($message->name); ?></div>
                                                <div class="text-gray-500 small"><?php echo e($message->message); ?></div>
                                            </div>
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <a class="text-center text-gray-500 dropdown-item small" href="#">Read More Messages</a>
                                </div>
                            </li>

                            <div class="topbar-divider d-none d-sm-block"></div>

                            <!-- Nav Item - User Information -->
                            <li class="nav-item dropdown no-arrow">
                                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                    <span class="mr-2 text-gray-600 d-none d-lg-inline small">
                                    <?php echo e(Auth::user()->name); ?>

                                    </span>
                                    <img class="img-profile rounded-circle"
                                        src="<?php echo e(asset('logo1.png')); ?>">
                                </a>
                                <!-- Dropdown - User Information -->
                                <div class="shadow dropdown-menu dropdown-menu-right animated--grow-in"
                                    aria-labelledby="userDropdown">

                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                        <i class="mr-2 text-gray-400 fas fa-sign-out-alt fa-sm fa-fw"></i>
                                        Logout
                                    </a>
                                </div>
                            </li>

                        </ul>

                    </nav>
                    <!-- End of Topbar -->

                    <!-- Begin Page Content -->
                    <div id="dashboardpage"   class="container-fluid">

                        <!-- Page Heading -->
                        <div class="mb-4 d-sm-flex align-items-center justify-content-between">
                            <h1 class="mb-0 text-gray-800 h3">  <?php echo e(__('Dashboard')); ?></h1>
                            <a data-bs-toggle="modal" data-bs-target="#generatereport"  href="#" class="shadow-sm d-none d-sm-inline-block btn btn-sm btn-success"><i
                                    class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
                        </div>
                                <!-- Modal -->
                                <div class="modal fade" id="generatereport" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Generate Report</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">

                                            <a class="px-5 m-2 rounded w-100 bg-success" target="_blank" href="<?php echo e(route('generate-report-all')); ?>">All</a>
                                            <a class="px-5 m-2 rounded w-100 bg-success" target="_blank" href="<?php echo e(route('generate-report-farmers')); ?>">Farmers</a>
                                            <a class="px-5 m-2 rounded w-100 bg-success" target="_blank" href="<?php echo e(route('generate-report-damages')); ?>">Damages</a>
                                        </div>
                                        <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        
                                        </div>
                                    </div>
                                    </div>
                                </div>



                        <!-- Content Row -->
                        <div class="row">

                            <!-- Admins (Monthly) Card Example -->
                            <div class="mb-4 col-xl-3 col-md-6">
                                <div class="py-2 shadow card border-left-info h-100">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="mr-2 col">
                                                <div class="mb-1 text-xs font-weight-bold text-info text-uppercase">Admin
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-auto">
                                                        <div class="mb-0 mr-3 text-gray-800 h5 font-weight-bold">
                                                            <?php
                                                                $collectadmins = Auth::user()->whereRoleIs('admin')->count();
                                                            ?>
                                                                <?php echo e($collectadmins); ?>

                                                        </div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="mr-2 progress progress-sm">
                                                            <div class="progress-bar bg-info" role="progressbar"
                                                                style="width: 50%" aria-valuenow="75" aria-valuemin="0"
                                                                aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="text-gray-300 fas fa-2x fa-solid fa-users-gear"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Farmers (all) Card Example -->
                            <div class="mb-4 col-xl-3 col-md-6">
                                <div class="py-2 shadow card border-left-primary h-100">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="mr-2 col">
                                                <div class="mb-1 text-xs font-weight-bold text-primary text-uppercase">
                                                    Farmers (All)</div>
                                                <div class="mb-0 text-gray-800 h5 font-weight-bold">
                                                    <?php
                                                        $farmerscount =  Auth::user()->whereRoleIs('farmer')->count();
                                                    ?>
                                                    <?php echo e($farmerscount); ?>

                                                    users</div>
                                            </div>
                                            <div class="col-auto">
                                            <i class="text-gray-300 fas fa-2x fa-solid fa-user-tie"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Damages (all) Card Example -->
                            <div class="mb-4 col-xl-3 col-md-6">
                                <div class="py-2 shadow card border-left-success h-100">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="mr-2 col">
                                                <div class="mb-1 text-xs font-weight-bold text-success text-uppercase">
                                                    Reports (All)</div>
                                                <div class="mb-0 text-gray-800 h5 font-weight-bold">
                                                    <?php
                                                        $damagescount = App\Models\Report::count();
                                                    ?>
                                                    <?php echo e($damagescount); ?>

                                                farms</div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="text-gray-300 fas fa-2x fa-regular fa-tractor"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Pending Requests Card Example -->
                            <div class="mb-4 col-xl-3 col-md-6">
                                <div class="py-2 shadow card border-left-warning h-100">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="mr-2 col">
                                                <div class="mb-1 text-xs font-weight-bold text-warning text-uppercase">
                                                    Pending Requests</div>
                                                <div class="mb-0 text-gray-800 h5 font-weight-bold">

                                                <?php echo e($count); ?> requests
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="text-gray-300 fas fa-comments fa-2x"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                <!-- Page Content -->
                <main>
                    <?php echo e($slot); ?>

                </main>




                    </div>

                    <!-- /.container-fluid -->


                    <div id="aboutpage" style="display: none;">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.about','data' => []]); ?>
<?php $component->withName('about'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div id="servicespage" style="display:none;">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.services','data' => []]); ?>
<?php $component->withName('services'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                </div>
                <!-- End of Main Content -->



                <!-- Footer -->
                <footer class="bg-white sticky-footer">
                    <div class="container my-auto">
                        <div class="my-auto text-center copyright">
                            <span>Copyright &copy; MAO Portal 2022</span>
                        </div>
                    </div>
                </footer>
                <!-- End of Footer -->


            </div>
            <!-- End of Content Wrapper -->

        </div>
        <!-- End of Page Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="rounded scroll-to-top" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <!-- Logout Modal-->
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                        <!-- Authentication -->
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>

                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.responsive-nav-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']]); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']); ?>
                            <?php echo e(__('Log Out')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php elseif(Auth::user()->hasRole('farmer')): ?>
    <div class="">


        <!-- Page Wrapper -->
        <div id="wrapper">

            <!-- Sidebar -->
            <ul class="navbar-nav bg-gradient-success sidebar sidebar-dark accordion " id="accordionSidebar">

                <!-- Sidebar - Brand -->
                <a class="sidebar-brand d-flex align-items-center justify-content-center" href="">
                    <div class="sidebar-brand-icon rotate-n-15">
                        <img src="<?php echo e(asset('logo1.png')); ?>" width="60px" alt="">
                    </div>
                    <div class="mx-3 sidebar-brand-text">MAO<sup>farmer</sup></div>
                </a>

                <!-- Divider -->
                <hr class="my-0 sidebar-divider">

                <!-- Nav Item - Dashboard -->
                <li class="nav-item active">
                    <button onclick="dashboardFunc()"  class="nav-link" >
                        <i class="fas fa-fw fa-tachometer-alt"></i>
                        Dashboard
                    </button>
                </li>

                <!-- Divider -->
                <hr class="sidebar-divider">

                <!-- Heading -->
                <div class="sidebar-heading">
                    Menus
                </div>

                <!-- Nav Item - Pages Collapse Menu -->
                <li class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                        aria-expanded="true" aria-controls="collapseTwo">
                        <i class="fas fa-fw fa-folder"></i>
                        <span>Pages</span>
                    </a>
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                        <div class="py-2 bg-white rounded collapse-inner">
                            <h6 class="collapse-header">Web Pages:</h6>
                            <button onclick="aboutFunc()"   class="text-left collapse-item w-100" >About</button>
                            <button onclick="servicesFunc()" class="text-left collapse-item w-100" >Services</button>
                            <button onclick="contactsFunc()" class="text-left collapse-item w-100" >Contact</button>
                        </div>
                    </div>
                </li>



                <!-- Divider -->
                <hr class="sidebar-divider d-none d-md-block">

                <!-- Sidebar Toggler (Sidebar) -->
                <div class="text-center d-none d-md-inline">
                    <button class="border-0 rounded-circle" id="sidebarToggle"></button>
                </div>



            </ul>
            <!-- End of Sidebar -->

            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">

                <!-- Main Content -->
                <div id="content">

                    <!-- Topbar -->
                    <nav class="mb-4 bg-white shadow navbar navbar-expand navbar-light topbar static-top">

                        <!-- Sidebar Toggle (Topbar) -->
                        <button id="sidebarToggleTop" class="mr-3 btn btn-link d-md-none rounded-circle">
                            <i class="fa fa-bars"></i>
                        </button>

                        <!-- Topbar Navbar -->
                        <ul class="ml-auto navbar-nav">

                            <?php

                                $countrequest = App\Models\ContactRequest::where('email', Auth::user()->email)->count();
                            ?>
                            <!-- Nav Item - Messages -->
                            <li class="mx-1 nav-item dropdown no-arrow">
                                <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-envelope fa-fw"></i>
                                    <!-- Counter - Messages -->
                                    <span class="badge badge-danger badge-counter">


                                        <?php echo e($countrequest); ?>


                                    </span>
                                </a>
                                <!-- Dropdown - Messages -->
                                <div class="shadow dropdown-list dropdown-menu dropdown-menu-right animated--grow-in"
                                    aria-labelledby="messagesDropdown">
                                    <h6 class="dropdown-header">
                                        Message Center
                                    </h6>
                                    <?php
                                        $messages = App\Models\ContactRequest::where('email', Auth::user()->email)->get();
                                    ?>
                                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="mr-3 dropdown-list-image">
                                                <i class="text-gray-500 fas fa-2x fa-solid fa-user-tie"></i>

                                                <div class="status-indicator bg-success"></div>
                                            </div>
                                            <div class="font-weight-bold">
                                                <div class="text-truncate"><?php echo e($message->name); ?></div>
                                                <div class="text-gray-500 small"><?php echo e($message->message); ?></div>
                                            </div>
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <a class="text-center text-gray-500 dropdown-item small" href="#">Read More Messages</a>
                                </div>
                            </li>

                            <div class="topbar-divider d-none d-sm-block"></div>

                            <!-- Nav Item - User Information -->
                            <li class="nav-item dropdown no-arrow">
                                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                    <span class="mr-2 text-gray-600 d-none d-lg-inline small">
                                    <?php echo e(Auth::user()->name); ?>

                                    </span>
                                    <img class="img-profile rounded-circle"
                                        src="<?php echo e(asset('logo1.png')); ?>">
                                </a>
                                <!-- Dropdown - User Information -->
                                <div class="shadow dropdown-menu dropdown-menu-right animated--grow-in"
                                    aria-labelledby="userDropdown">
                                    
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                        <i class="mr-2 text-gray-400 fas fa-sign-out-alt fa-sm fa-fw"></i>
                                        Logout
                                    </a>
                                </div>
                            </li>

                        </ul>

                    </nav>
                    <!-- End of Topbar -->

                    <!-- Begin Page Content -->
                    <div id="dashboardpage"   class="container-fluid">

                        <!-- Page Heading -->
                        <div class="mb-4 d-sm-flex align-items-center justify-content-between">
                            <h1 class="mb-0 text-gray-800 h3">  <?php echo e(__('Dashboard')); ?></h1>
                            <form action="<?php echo e(route('generate-report-farmer')); ?>" target="_blank" method="GET" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <a href="" class="shadow-sm d-none d-sm-inline-block btn btn-sm btn-success">
                                    <i class="fas fa-download fa-sm text-white-50"></i>

                                    <input type="submit" value=" Generate Report">
                                </a>
                                <input type="hidden" name="$emailna" value="<?php echo e(Auth::user()->email); ?>">
                            </form>
                        </div>
                        <!-- Content Row -->
                        <div class="row">
                            <?php if(Auth::user()->hasRole('admin')): ?>


                                <!-- Admins (Monthly) Card Example -->
                                <div class="mb-4 col-xl-3 col-md-6">
                                    <div class="py-2 shadow card border-left-info h-100">
                                        <div class="card-body">
                                            <div class="row no-gutters align-items-center">
                                                <div class="mr-2 col">
                                                    <div class="mb-1 text-xs font-weight-bold text-info text-uppercase">Admin
                                                    </div>
                                                    <div class="row no-gutters align-items-center">
                                                        <div class="col-auto">
                                                            <div class="mb-0 mr-3 text-gray-800 h5 font-weight-bold">
                                                                <?php
                                                                    $collectadmins = Auth::user()->whereRoleIs('admin')->count();
                                                                ?>
                                                                <?php echo e($collectadmins); ?>

                                                            </div>
                                                        </div>
                                                        <div class="col">
                                                            <div class="mr-2 progress progress-sm">
                                                                <div class="progress-bar bg-info" role="progressbar"
                                                                    style="width: 50%" aria-valuenow="75" aria-valuemin="0"
                                                                    aria-valuemax="100"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="text-gray-300 fas fa-2x fa-solid fa-users-gear"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <!-- Farmers (all) Card Example -->
                            <div class="mb-4 col-xl-3 col-md-6">
                                <div class="py-2 shadow card border-left-primary h-100">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="mr-2 col">
                                                <div class="mb-1 text-xs font-weight-bold text-primary text-uppercase">
                                                    Farmers (All)</div>
                                                <div class="mb-0 text-gray-800 h5 font-weight-bold">
                                                    <?php
                                                        $collectfarmers = Auth::user()->whereRoleIs('farmer')->count();
                                                    ?>
                                                     <?php echo e($collectfarmers); ?> users</div>
                                            </div>
                                            <div class="col-auto">
                                            <i class="text-gray-300 fas fa-2x fa-solid fa-user-tie"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Damages (all) Card Example -->
                            <div class="mb-4 col-xl-3 col-md-6">
                                <div class="py-2 shadow card border-left-success h-100">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="mr-2 col">
                                                <div class="mb-1 text-xs font-weight-bold text-success text-uppercase">
                                                    Reports (All)</div>
                                                <div class="mb-0 text-gray-800 h5 font-weight-bold">
                                                    <?php
                                                        $damagescount = App\Models\Report::count();
                                                    ?>
                                                <?php echo e($damagescount); ?>

                                                farms</div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="text-gray-300 fas fa-2x fa-regular fa-tractor"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Pending Requests Card Example -->
                            <div class="mb-4 col-xl-3 col-md-6">
                                <div class="py-2 shadow card border-left-warning h-100">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="mr-2 col">
                                                <div class="mb-1 text-xs font-weight-bold text-warning text-uppercase">
                                                    Pending Requests</div>
                                                <div class="mb-0 text-gray-800 h5 font-weight-bold">

                                                <?php echo e($countrequest); ?> requests
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="text-gray-300 fas fa-comments fa-2x"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                <!-- Page Content -->
                <main>
                    <?php echo e($slot); ?>

                </main>




                    </div>

                    <!-- /.container-fluid -->


                    <div id="aboutpage" style="display: none;">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.about','data' => []]); ?>
<?php $component->withName('about'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div id="servicespage" style="display:none;">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.services','data' => []]); ?>
<?php $component->withName('services'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                    <div id="contactspage" style="display:none;">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.contact','data' => []]); ?>
<?php $component->withName('contact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                </div>
                <!-- End of Main Content -->



                <!-- Footer -->
                <footer class="bg-white sticky-footer">
                    <div class="container my-auto">
                        <div class="my-auto text-center copyright">
                            <span>Copyright &copy; MAO Portal 2022</span>
                        </div>
                    </div>
                </footer>
                <!-- End of Footer -->


            </div>
            <!-- End of Content Wrapper -->

        </div>
        <!-- End of Page Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="rounded scroll-to-top" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <!-- Logout Modal-->
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                        <!-- Authentication -->
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>

                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.responsive-nav-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']]); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']); ?>
                            <?php echo e(__('Log Out')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php elseif(Auth::user()->hasRole('guest')): ?>

    <div class="">


        <!-- Page Wrapper -->
        <div id="wrapper">

            <!-- Sidebar -->
            <ul class="navbar-nav bg-gradient-success sidebar sidebar-dark accordion " id="accordionSidebar">

                <!-- Sidebar - Brand -->
                <a class="sidebar-brand d-flex align-items-center justify-content-center" href="">
                    <div class="sidebar-brand-icon rotate-n-15">
                        <img src="<?php echo e(asset('logo1.png')); ?>" width="60px" alt="">
                    </div>
                    <div class="mx-3 sidebar-brand-text">MAO<sup>farmer</sup></div>
                </a>

                <!-- Divider -->
                <hr class="my-0 sidebar-divider">

                <!-- Nav Item - Dashboard -->
                <li class="nav-item active">
                    <button onclick="dashboardFunc()"  class="nav-link" >
                        <i class="fas fa-fw fa-tachometer-alt"></i>
                        Dashboard
                    </button>
                </li>

                <!-- Divider -->
                <hr class="sidebar-divider">

                <!-- Heading -->
                <div class="sidebar-heading">
                    Menus
                </div>

                <!-- Nav Item - Pages Collapse Menu -->
                <li class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                        aria-expanded="true" aria-controls="collapseTwo">
                        <i class="fas fa-fw fa-folder"></i>
                        <span>Pages</span>
                    </a>
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                        <div class="py-2 bg-white rounded collapse-inner">
                            <h6 class="collapse-header">Web Pages:</h6>
                            <button onclick="aboutFunc()"   class="text-left collapse-item w-100" >About</button>
                            <button onclick="servicesFunc()" class="text-left collapse-item w-100" >Services</button>
                            <button onclick="contactsFunc()" class="text-left collapse-item w-100" >Contact</button>
                        </div>
                    </div>
                </li>



                <!-- Divider -->
                <hr class="sidebar-divider d-none d-md-block">

                <!-- Sidebar Toggler (Sidebar) -->
                <div class="text-center d-none d-md-inline">
                    <button class="border-0 rounded-circle" id="sidebarToggle"></button>
                </div>



            </ul>
            <!-- End of Sidebar -->

            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">

                <!-- Main Content -->
                <div id="content">

                    <!-- Topbar -->
                    <nav class="mb-4 bg-white shadow navbar navbar-expand navbar-light topbar static-top">

                        <!-- Sidebar Toggle (Topbar) -->
                        <button id="sidebarToggleTop" class="mr-3 btn btn-link d-md-none rounded-circle">
                            <i class="fa fa-bars"></i>
                        </button>

                        <!-- Topbar Search -->
                        

                        <!-- Topbar Navbar -->
                        <ul class="ml-auto navbar-nav">



                            <?php
                                $count = App\Models\ContactRequest::where('email',Auth::user()->email)->count();
                            ?>
                            <!-- Nav Item - Messages -->
                            <li class="mx-1 nav-item dropdown no-arrow">
                                <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-envelope fa-fw"></i>
                                    <!-- Counter - Messages -->
                                    <span class="badge badge-danger badge-counter">


                                        <?php echo e($count); ?>


                                    </span>
                                </a>
                                <!-- Dropdown - Messages -->
                                <div class="shadow dropdown-list dropdown-menu dropdown-menu-right animated--grow-in"
                                    aria-labelledby="messagesDropdown">
                                    <h6 class="dropdown-header">
                                        Message Center
                                    </h6>
                                    <?php
                                        $messages = App\Models\ContactRequest::where('email', Auth::user()->email)->get();
                                    ?>
                                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="mr-3 dropdown-list-image">
                                                <i class="text-gray-500 fas fa-2x fa-solid fa-user-tie"></i>

                                                <div class="status-indicator bg-success"></div>
                                            </div>
                                            <div class="font-weight-bold">
                                                <div class="text-truncate"><?php echo e($message->name); ?></div>
                                                <div class="text-gray-500 small"><?php echo e($message->message); ?></div>
                                            </div>
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <a class="text-center text-gray-500 dropdown-item small" href="#">Read More Messages</a>
                                </div>
                            </li>

                            <div class="topbar-divider d-none d-sm-block"></div>

                            <!-- Nav Item - User Information -->
                            <li class="nav-item dropdown no-arrow">
                                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                    <span class="mr-2 text-gray-600 d-none d-lg-inline small">
                                    <?php echo e(Auth::user()->name); ?>

                                    </span>
                                    <img class="img-profile rounded-circle"
                                        src="<?php echo e(asset('logo1.png')); ?>">
                                </a>
                                <!-- Dropdown - User Information -->
                                <div class="shadow dropdown-menu dropdown-menu-right animated--grow-in"
                                    aria-labelledby="userDropdown">
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                        <i class="mr-2 text-gray-400 fas fa-sign-out-alt fa-sm fa-fw"></i>
                                        Logout
                                    </a>
                                </div>
                            </li>

                        </ul>

                    </nav>
                    <!-- End of Topbar -->

                    <!-- Begin Page Content -->
                    <div id="dashboardpage"   class="container-fluid">

                        <?php if(Auth::user()->hasRole('admin')): ?>
                            <!-- Page Heading -->
                            <div class="mb-4 d-sm-flex align-items-center justify-content-between">
                                <h1 class="mb-0 text-gray-800 h3">  <?php echo e(__('Dashboard')); ?></h1>
                                <a data-bs-toggle="modal" data-bs-target="#generatereport"  href="#" class="shadow-sm d-none d-sm-inline-block btn btn-sm btn-success"><i
                                        class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
                            </div>
                        <?php endif; ?>

                                <!-- Modal -->
                                <div class="modal fade" id="generatereport" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Generate Report</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">

                                            <a class="px-5 m-2 rounded w-100 bg-success" target="_blank" href="<?php echo e(route('generate-report-all')); ?>">All</a>
                                            <a class="px-5 m-2 rounded w-100 bg-success" target="_blank" href="<?php echo e(route('generate-report-admins')); ?>">Admin</a>
                                            <a class="px-5 m-2 rounded w-100 bg-success" target="_blank" href="generate-report-farmers">Farmers</a>
                                            <a class="px-5 m-2 rounded w-100 bg-success" target="_blank" href="<?php echo e(route('generate-report-damages')); ?>">Damages</a>
                                        </div>
                                        <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        
                                        </div>
                                    </div>
                                    </div>
                                </div>



                        <!-- Content Row -->
                        <div class="row">
                            <?php if(Auth::user()->hasRole('admin')): ?>
                            <!-- Admins (Monthly) Card Example -->
                            <div class="mb-4 col-xl-3 col-md-6">
                                <div class="py-2 shadow card border-left-info h-100">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="mr-2 col">
                                                <div class="mb-1 text-xs font-weight-bold text-info text-uppercase">Admin
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-auto">
                                                        <div class="mb-0 mr-3 text-gray-800 h5 font-weight-bold">
                                                            Wala pa
                                                        </div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="mr-2 progress progress-sm">
                                                            <div class="progress-bar bg-info" role="progressbar"
                                                                style="width: 50%" aria-valuenow="75" aria-valuemin="0"
                                                                aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="text-gray-300 fas fa-2x fa-solid fa-users-gear"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                            <!-- Farmers (all) Card Example -->
                            <div class="mb-4 col-xl-3 col-md-6">
                                <div class="py-2 shadow card border-left-primary h-100">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="mr-2 col">
                                                <div class="mb-1 text-xs font-weight-bold text-primary text-uppercase">
                                                    Farmers (All)</div>
                                                <div class="mb-0 text-gray-800 h5 font-weight-bold">
                                                    <?php
                                                        $farmerscount = App\Models\User::count();
                                                    ?>
                                                    <?php echo e($farmerscount); ?>

                                                    users</div>
                                            </div>
                                            <div class="col-auto">
                                            <i class="text-gray-300 fas fa-2x fa-solid fa-user-tie"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                          <!-- Damages (all) Card Example -->
                          <div class="mb-4 col-xl-3 col-md-6">
                            <div class="py-2 shadow card border-left-success h-100">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="mr-2 col">
                                            <div class="mb-1 text-xs font-weight-bold text-success text-uppercase">
                                                Reports (All)</div>
                                            <div class="mb-0 text-gray-800 h5 font-weight-bold">
                                                <?php
                                                    $damagescount = App\Models\Report::count();
                                                ?>
                                            <?php echo e($damagescount); ?>

                                            farms</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="text-gray-300 fas fa-2x fa-regular fa-tractor"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                            <!-- Pending Requests Card Example -->
                            <div class="mb-4 col-xl-3 col-md-6">
                                <div class="py-2 shadow card border-left-warning h-100">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="mr-2 col">
                                                <div class="mb-1 text-xs font-weight-bold text-warning text-uppercase">
                                                    Pending Requests</div>
                                                <div class="mb-0 text-gray-800 h5 font-weight-bold">

                                                <?php echo e($count); ?> requests
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="text-gray-300 fas fa-comments fa-2x"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                <!-- Page Content -->
                <main>
                    <?php echo e($slot); ?>

                </main>




                    </div>

                    <!-- /.container-fluid -->


                    <div id="aboutpage" style="display: none;">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.about','data' => []]); ?>
<?php $component->withName('about'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div id="servicespage" style="display:none;">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.services','data' => []]); ?>
<?php $component->withName('services'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div id="contactspage" style="display:none;">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.contact','data' => []]); ?>
<?php $component->withName('contact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                </div>
                <!-- End of Main Content -->



                <!-- Footer -->
                <footer class="bg-white sticky-footer">
                    <div class="container my-auto">
                        <div class="my-auto text-center copyright">
                            <span>Copyright &copy; MAO Portal 2022</span>
                        </div>
                    </div>
                </footer>
                <!-- End of Footer -->


            </div>
            <!-- End of Content Wrapper -->

        </div>
        <!-- End of Page Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="rounded scroll-to-top" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <!-- Logout Modal-->
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                        <!-- Authentication -->
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>

                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.responsive-nav-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']]); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']); ?>
                            <?php echo e(__('Log Out')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /home/u491758168/domains/maomamburao.com/resources/views/layouts/navigation.blade.php ENDPATH**/ ?>