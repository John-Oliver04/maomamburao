<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Report;
use App\Models\Photo;

class ReportController extends Controller
{
     // Store
     public function store(Request $request)
     {


        if(Auth::user()->hasRole('farmer')){

         $damages = new Report;

         $damages->email = Auth::user()->id;
         $damages->crop = $request->input('crop');
         $damages->losses = $request->input('losses');
         $damages->hectare = $request->input('hectare');
         $damages->disaster = $request->input('disaster');
         $damages->date = $request->input('dated');
         $damages->image_id = random_int ( 1000,90000);

         $img = new Photo;
         $request->validate([
             'photos' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
         ]);

         if ($request->file('photos')) {

            $fileName = time().".".$request->file('photos')->getClientOriginalExtension();
            $request->file('photos')->move('images', $fileName);

            $img->name = $fileName;
            $img->report_id = $damages->image_id;


            $img->save();

         }


         $damages->save();



         return redirect()->back()->with('success','Successfully Added to Damage Report!');
        }
     }

     public function addimage(Request $request)
     {
             $img = new Photo;

         $request->validate([
             'photos' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
         ]);

         if ($request->file('photos')) {
             $fileName = time().'.'.$request->file('photos')->getClientOriginalExtension();

             $request->file('photos')->move('images', $fileName);

             $img->report_id =  $request->input('hiddenid');
             $img->name = $fileName;
             $img->save();

         }

             return redirect()->back()->with('success','Photos was Successfully Added!');
     }
}
