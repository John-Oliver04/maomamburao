<x-app-layout>
    <x-slot name="header">
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    You're logged in as Guest!
                </div>
            </div>
        </div>
    </div>

    @php
        $infos = App\Models\Info::all();
    @endphp
    @foreach ($infos as $info)
        @if ($info->user_id == Auth::user()->email)
            <ul class="list-group">

                <li class="justify-between list-group-item bg-success d-flex" aria-current="true">
                <b class="text-white"> Personal Information</b>
                <button onclick="enabletext()" ><i class="fa fas fa-regular fa-pen-to-square"></i></button>
                </li>
                <div id="disabledtext">
                    <li class="list-group-item"><b>FirstName:</b> <input value="{{ $info->firstname }}" disabled placeholder="Enter firstname.." class="border-0" type="text" name="" id=""></li>
                    <li class="list-group-item"><b>MiddleName:</b><input value="{{ $info->middlename }}" disabled placeholder="Enter middlename.." class="border-0" type="text" name="middename" id=""> </li>
                    <li class="list-group-item"><b>LastName:</b> <input value="{{ $info->lastname }}" disabled  placeholder="Enter lastname.." class="border-0" type="text" name="" id=""></li>
                    <li class="list-group-item"><b>Age:</b> <input value="{{ $info->age }}" disabled placeholder="Enter age.." class="border-0" type="text" name="" id=""></li>
                    <li class="list-group-item"><b>Gender:</b> <input value="{{ $info->gender }}" disabled placeholder="Enter gender.." class="border-0" type="text" name="" id=""></li>
                    <li class="list-group-item"><b>Birthday:</b> <input value="{{ $info->birthday }}" disabled placeholder="Enter birthday.." class="border-0" type="text" name="" id=""></li>
                    <li class="list-group-item"><b>Address:</b> <input value="{{ $info->address }}" disabled placeholder="Enter address.." class="border-0" type="text" name="" id=""></li>
                    <li class="list-group-item"><b>RSBSA:</b><input value="{{ $info->rsbsa }}" disabled placeholder="Enter RSBSA.." class="border-0" type="text" name="" id=""> </li>
                    <li class="list-group-item"><b>Contacts:</b><input value="{{ $info->contacts }}" disabled placeholder="Enter contact number.." class="border-0" type="text" name="" id=""> </li>
                    <li class="text-right list-group-item"><button disabled class="btn btn-success btn-sm">Save</button></li>
                </div>
                <form  action="{{url('dashboard-updateinfo')}}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div id="enabledtext" style="display: none;">
                        <li class="list-group-item"><b>FirstName:</b> <input  value="{{ $info->firstname }}" placeholder="Enter firstname.." class="border-0" type="text" name="firstname" id=""></li>
                        <li class="list-group-item"><b>MiddleName:</b><input value="{{ $info->middlename }}"  placeholder="Enter middlename.." class="border-0" type="text" name="middlename" id=""> </li>
                        <li class="list-group-item"><b>LastName:</b> <input  value="{{ $info->lastname }}"  placeholder="Enter lastname.." class="border-0" type="text" name="lastname" id=""></li>
                        <li class="list-group-item"><b>Age:</b> <input  value="{{ $info->age }}" placeholder="Enter age.." class="border-0" type="text" name="age" id=""></li>
                        <li class="list-group-item"><b>Gender:</b> <input  value="{{ $info->gender }}" placeholder="Enter gender.." class="border-0" type="text" name="gender" id=""></li>
                        <li class="list-group-item"><b>Birthday:</b> <input value="{{ $info->birthday }}"  placeholder="Enter birthday.." class="border-0" type="text" name="birthday" id=""></li>
                        <li class="list-group-item"><b>Address:</b> <input  value="{{ $info->address }}" placeholder="Enter address.." class="border-0" type="text" name="address" id=""></li>
                        <li class="list-group-item"><b>RSBSA:</b><input  value="{{ $info->rsbsa }}" placeholder="Enter RSBSA.." class="border-0" type="text" name="rsbsa" id=""> </li>
                        <li class="list-group-item"><b>Contacts:</b><input value="{{ $info->contacts }}" placeholder="Enter contact number.." class="border-0" type="text" name="contacts" id=""> </li>

                        <li class="text-right list-group-item"><input type="submit"  class="btn btn-success btn-sm" value="Save"/></li>
                    </div>
                </form>
            </ul>

        @endif
    @endforeach

  </x-app-layout>
