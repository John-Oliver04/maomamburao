<div class="container px-5 py-5 mx-5 bg-dark" id="services">
    <div class="mx-auto mb-5 text-center" style="max-width: 600px;">
        <h1 class="mb-4 text-white display-5 text-uppercase">We Provide <span class="text-success">The Best</span> Services for you!</h1>
    </div>

    <div class="mt-4 rounded shadow row bg-success">
        <div class="p-3 w-100 col-sm-3">
          <div class="card">
            <div class="card-body">

                <h5 class="card-title">Application for Municipal fishing vessel/gear licence</h5>
              <p class="card-text">Pursuant to Municipal Ordinance no. 6 series of 2002, the municipal agriculture office facilitate application for Municipal fishing vessel/ gear licence.</p>
              <div class="d-flex">
                <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">

              </div>

            </div>
          </div>
        </div>
        <div class="p-3 col-sm-3 w-100">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Application for Crop Insurance</h5>
              <p class="card-text">The Municipal Agriculture Office facilitates Application for Crop Insurance at least
                10 days after transplanting/planting</p>
               <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
            </div>
          </div>
        </div>
        <div class="p-3 col-sm-3 w-100">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Application for HVCC Insurance</h5>
                <p class="card-text">The Municipal Agriculture Office facilitates Application for HVCC Insurance at least
                    10 days after transplanting/planting.</p>
                 <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
              </div>
            </div>
          </div>
        <div class="p-3 col-sm-3 w-100">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Application for Agricultural Competitiveness Enhancement Fund
              (ACEF) Loan-Agriculture</h5>
              <p class="card-text">The Municipal Agriculture Office facilitates Application for Agricultural
                Competitiveness Enhancement Fund (ACEF) Loan-Agriculture</p>
               <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
            </div>
          </div>
        </div>
    </div>

    <div class="mt-4 row">
        <div class="p-3 col-sm-3 w-100">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">DA-Accreditation of Registered Farmers and Cooperatives
                    Association (FCA)</h5>
                <p class="card-text">The Municipal Agriculture Office facilitates requirements for accreditation of
                    registered FCAs and issues MAO Endorsement upon completion of documentary
                    requirements.</p>
                 <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
              </div>
            </div>
          </div>
          <div class="p-3 col-sm-3 w-100">
            <div class="card">
            <div class="card-body">
              <h5 class="card-title">Training Services</h5>
              <p class="card-text">The Office of the Municipal Agriculturist renders training based on the needs and
                request of farmers, fisherfolk, youth, and women’s organizations, association or
                cooperatives..</p>
               <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
            </div>
          </div>
        </div>
        <div class="p-3 col-sm-3 w-100">
            <div class="card">
            <div class="card-body">
              <h5 class="card-title">Farm and Business Advisory Services</h5>
              <p class="card-text">Technical Assistance is provided to clients to help increase the productivity of the
                farmers and fisherfolk.</p>
                <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
            </div>
          </div>
        </div>
        <div class="p-3 col-sm-3 w-100">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Demonstration Services (Contiguous Farming/Model Farms)</h5>
                <p class="card-text">The Office of the Municipal Agriculturist carries out contiguous farming projects in order to effect suitable field shapes and sizes conducive to efficient operation of agricultural machinery and equipment, and likewise to ensure economies of scale.</p>
                 <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
              </div>
            </div>
          </div>
    </div>

    <div class="mt-4 rounded shadow row bg-success">
        <div class="p-3 col-sm-3 w-100">
            <div class="card">
            <div class="card-body">
              <h5 class="card-title">Certification (Regular)</h5>
              <p class="card-text">The Municipal Agriculture Office issues Certification as requested by the farmers
                and fishers.</p>
               <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
            </div>
          </div>
        </div>

        <div class="p-3 col-sm-3 w-100">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Information and communication support services through tri-media</h5>
              <p class="card-text">The Office of the Municipal Agriculturist carries out contiguous farming projects in order to effect suitable field shapes and sizes conducive to efficient operation of agricultural machinery and equipment, and likewise to ensure economies of scale
                .</p>
               <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
            </div>
          </div>
        </div>
        <div class="p-3 col-sm-3 w-100">
            <div class="card">
            <div class="card-body">
              <h5 class="card-title">Farm Plan and Budget (Regular)</h5>
              <p class="card-text">The Municipal Agriculture Office issues Farm Plan and Budget as requirement for loan applications</p>
               <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
            </div>
          </div>
        </div>
        <div class="p-3 col-sm-3 w-100">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Issuance of Auxiliary Invoice</h5>
                <p class="card-text">An Auxiliary Invoice is required before fish traders can transport fish and other fishery products from the municipality pursuant to Municipal Ordinance No. 3 Series of 2002</p>
                 <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
              </div>
            </div>
          </div>
    </div>

    <div class="mt-4 row">
        <div class="p-3 col-sm-3 w-100">
            <div class="card">
            <div class="card-body">
              <h5 class="card-title">Issuance of Fisherfolk ID</h5>
              <p class="card-text">Pursuant to Municipal Ordinance No. 3 Series of 2002, municipal fisherfolk must secure Fisherfolk ID before fishing in the municipal waters</p>
               <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
            </div>
          </div>
        </div>
        <div class="p-3 col-sm-3 w-100">
            <div class="card">
            <div class="card-body">
              <h5 class="card-title">Registry System for Basic Sectors in Agriculture (RSBSA)</h5>
              <p class="card-text">The Municipal Agriculture Office facilitates enrolment of farmers, agri-youth and fisherfolk in the Registry System for Basic Sectors in Agriculture where RSBSA Number is issued by the Department of Agriculture.</p>
               <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
            </div>
          </div>
        </div>
        <div class="p-3 col-sm-3 w-100">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Rice Competitiveness Enhancement Fund-Rice Farm Machineries and Equipment</h5>
                <p class="card-text">The Municipal Agriculture Office facilitates request of machineries and equipment by FCAs and issues MAO endorsement upon completion of documentary requirements</p>
                 <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
              </div>
            </div>
          </div>
          <div class="p-3 col-sm-3 w-100">
            <div class="card">
            <div class="card-body">
              <h5 class="card-title"> Rice Seed Distribution</h5>
              <p class="card-text">The Municipal Agriculture Office facilitates the distribution of seeds to the famer-beneficiaries</p>
               <img src=<?php echo e(url('logo1.png')); ?> width="32px" alt="">
            </div>
          </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\admin\Downloads\farmersportal\resources\views/components/services.blade.php ENDPATH**/ ?>