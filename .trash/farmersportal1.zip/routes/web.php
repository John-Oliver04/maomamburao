<?php

use App\Http\Controllers\ContactRequestController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\InfoController;
use App\Http\Controllers\ReportController;
use App\Models\Info;
use Illuminate\Routing\RouteGroup;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/dashboard', function () {
//     return view('dashboard');
// })->middleware(['auth'])->name('dashboard');

// auth route for both
Route::group(['middleware' => ['auth']], function(){
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
});


        // Generate Reports
    Route::get('/generate-report-all', function () {
        return view('admin.print.alldetails');
    })->name('generate-report-all');
    // Generate Reports

    Route::get('/generate-report-farmer',[InfoController::class,'show'])->name('generate-report-farmer');
    Route::get('/farmer-delete',[InfoController::class,'delete'])->name('farmer-delete');
    Route::get('/message-delete',[InfoController::class,'messagedelete'])->name('message-delete');
    Route::get('/report-delete',[InfoController::class,'reportdelete'])->name('report-delete');
    // Generate Reports
    Route::get('/generate-report-farmers', function () {
        return view('admin.print.farmerdetails');
    })->name('generate-report-farmers');
    // Generate Reports
    Route::get('/generate-report-damages', function () {
        return view('admin.print.damagedetails');
    })->name('generate-report-damages');


Route::post('/dashboard-register',[App\Http\Controllers\ReportController::class,'store'])->name('dashboard-register');

// start contact routes
Route::post('/dashboard-contact-save',[App\Http\Controllers\ContactRequestController::class,'saveRequest'])->name('dashboard-contact-save'); //contactsave
Route::get('/callback-request',function() {
    return view('components.contact-greetings');
});
// end contact routes

// Add image start
Route::post('/dashboard-addimage',[ReportController::class,'addimage']
)->middleware(['auth'])->name('dashboard-addimage');

// add image end

// Add farmer start
Route::post('/dashboard-addfarmer',[InfoController::class,'addfarmer']
)->middleware(['auth'])->name('dashboard-addfarmer');

// add farmer end


// Add info start
Route::post('/dashboard-updateinfo',[InfoController::class,'editinfo']
)->middleware(['auth'])->name('dashboard-updateinfo');

// add info end







require __DIR__.'/auth.php';
