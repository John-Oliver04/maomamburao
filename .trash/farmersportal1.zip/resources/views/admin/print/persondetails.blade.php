<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
       <!-- Fonts -->
       <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

       <!-- CSS only -->
       <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
       <!-- JavaScript Bundle with Popper -->
       <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
        <!-- Google WebFonts -->
       <link rel="preconnect" href="https://fonts.gstatic.com">
       <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">
       <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" integrity="sha384-xeJqLiuOvjUBq3iGOjvSQSIlwrpqjSHXpduPd6rQpuiM3f5/ijby8pCsnbu5S81n" crossorigin="anonymous">

       <!-- Icon Font Stylesheet -->
       <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">
       <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/fontawesome.min.css" integrity="sha512-giQeaPns4lQTBMRpOOHsYnGw1tGVzbAIHUyHRgn7+6FmiEgGGjaG0T2LZJmAPMzRCl+Cug0ItQ2xDZpTmEc+CQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
       <!-- Styles -->
       <link rel="stylesheet" href="{{ asset('css/app.css') }}">

       <!-- Scripts -->
       <script src="{{ asset('js/app.js') }}" defer></script>
       <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>



</head>
<body>

    <div class="container">

        <div class="text-center d-flex justify-content-center">
            <div class="justify-around d-flex">
                  <p></p><img width="100px" src="{{asset('logo1.png')}}" alt=""><p></p>
            </div>


        </div>
        <div class="text-center row">
               <p>Republic of the Phiippines</p>  <br>
               <p> Mamburao Occidental Mindoro</p> <br>
               <p>MUNICIPALITY OF MAMBURAO</p>  <br>
                                            <br>
               <b class="h3">Municipal Agriculture office</b>
        </div>
    </div>


    <hr class="my-5">


    <ul class="list-group">

        <li class="justify-between list-group-item bg-success d-flex" aria-current="true">
        <b class="text-white"> Farmers Information</b>
        {{-- <button onclick="enabletext()" ><i class="fa fas fa-regular fa-pen-to-square"></i></button> --}}
        </li>

        @foreach ($person as $info)

        <div id="enabledtext" style="">
            <li class="list-group-item"><b>FirstName:</b> <input  value="{{ $info->firstname }}"  class="border-0" type="text" name="firstname" id=""></li>
            <li class="list-group-item"><b>MiddleName:</b><input value="{{ $info->middlename }}"   class="border-0" type="text" name="middlename" id=""> </li>
            <li class="list-group-item"><b>LastName:</b> <input  value="{{ $info->lastname }}"  class="border-0" type="text" name="lastname" id=""></li>
            <li class="list-group-item"><b>Age:</b> <input  value="{{ $info->age }}"  class="border-0" type="text" name="age" id=""></li>
            <li class="list-group-item"><b>Gender:</b> <input  value="{{ $info->gender }}"  class="border-0" type="text" name="gender" id=""></li>
            <li class="list-group-item"><b>Birthday:</b> <input value="{{ $info->birthday }}"   class="border-0" type="text" name="birthday" id=""></li>
            <li class="list-group-item"><b>Address:</b> <input  value="{{ $info->address }}" class="border-0" type="text" name="address" id=""></li>
            <li class="list-group-item"><b>RSBSA:</b><input  value="{{ $info->rsbsa }}"  class="border-0" type="text" name="rsbsa" id=""> </li>
            <li class="list-group-item"><b>Contacts:</b><input value="{{ $info->contacts }}"  class="border-0" type="text" name="contacts" id=""> </li>
        </div>

        @php
            $reports = App\Models\Report::all();
            $users = App\Models\User::all();
        @endphp
<hr>
        <b class="p-3 mt-3 text-white bg-success w-100">Reports</b>

        @endforeach
        @foreach ($reports as $report)
            @foreach ($users as $user)
                @if ($report->email == $user->id)
                    @if ($info->user_id == $user->email)
                    <div class="mb-5">
                          <div class="my-3 col-md-4">
                            <b>Crop: </b><p>{{$report->crop}}</p>
                            <b>Estimated losses: </b><p>{{$report->losses}}</p>
                            <b>Hectare: </b><p>{{$report->hectare}}</p>
                            <b>Disaster: </b><p>{{$report->disaster}}</p>
                            <b>Date of disaster: </b><p>{{$report->date}}</p>

                        </div>
                        <div class="overflow-auto col-md-8">
                        <div class="justify-around d-flex">

                                @php
                                $images = App\Models\Photo::all();
                                @endphp

                                @foreach ($images as $photo)
                                @if ($photo->report_id == $report->image_id)
                                <div class="d-flex d-inline-flex ">
                                    <img width="300px" class="img-fluid img-thumbnail" src="{{asset('images').'/'.$photo->name}}" alt="">
                                </div>
                                @endif
                                @endforeach
                            </div>
                    </div>
                    </div>

<hr>
                    @endif
                @endif
            @endforeach
        @endforeach
    </ul>




</body>
</html>

