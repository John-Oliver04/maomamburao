<x-app-layout>
    <x-slot name="header">
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    You're logged in as Admin!
                </div>
            </div>
        </div>
    </div>

    <ul class="mt-3 overflow-hidden list-group">
        <li class="justify-between list-group-item bg-success d-flex" aria-current="true">
           <b class="text-white"> Farmers</b>
           {{-- <a href="/register" target="_blank"><i class="fa fas fa-solid fa-plus"></i></a> --}}
        </li>
        <div class="overflow-auto">
            <table class="table table-striped table-success table-hover">
                <thead>
                    <th>email</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Birthday</th>
                    <th>Address</th>
                    <th>RSBSA</th>
                    <th>Contacts</th>
                    <th>Action</th>
                </thead>
                <tbody>
                    @php
                        $countfarmers = Auth::user()->whereRoleIs('farmer')->get();
                        $countinfos = App\Models\Info::all();
                    @endphp

                    @foreach ($countfarmers as $farmer)
                        <tr>
                            @foreach ($countinfos as $info)
                                @if ($farmer->email == $info->user_id)
                                <td>{{$farmer->email}}</td>
                                <td>
                                    FirstName:  {{$info->firstname}} <br>
                                    MiddleName: {{$info->middlename}} <br>
                                    LastName: {{$info->lastname}}
                                </td>
                                <td>{{$info->age}}</td>
                                <td>{{$info->gender}}</td>
                                <td>{{$info->birthday}}</td>
                                <td>{{$info->address}}</td>
                                <td>{{$info->rsbsa}}</td>
                                <td>{{$info->contacts}}</td>
                                <td>

                                    <!--  single primary button -->
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-warning dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                        Action
                                        </button>
                                        <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#addfarmer{{$loop->index}}" href="#">Edit</a></li>
                                        <li>
                                            <form action="{{route('generate-report-farmer')}}" target="_blank" method="GET" enctype="multipart/form-data">
                                                @csrf
                                                <input class="dropdown-item" type="submit" value="Preview">
                                                <input type="hidden" name="$emailna" value="{{$farmer->email}}">
                                            </form>
                                        </li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li>
                                                <!-- Button trigger modal -->


                                                <a href="#" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#deleted{{$loop->index}}">
                                                    Delete
                                                </a>

                                            </li>
                                        </ul>
                                    </div>
                                </td>


                                <!-- Modal -->
                               <div name="deleted{{$loop->index}}" class="modal fade" id="deleted{{$loop->index}}"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                   <div class="modal-dialog">
                                       <div class="modal-content">
                                           <div class="modal-header">
                                           <h5 class="modal-title" id="staticBackdropLabel">Delete form</h5>
                                           <button  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                           </div>
                                           <div class="overflow-y-scroll modal-body">
                                                Do you want to delete this selected data? Click <b>Cancel</b> to refuse..

                                           </div>

                                           <div class="modal-footer">
                                               <button  class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                               <form action="{{route('farmer-delete')}}"  method="GET" enctype="multipart/form-data">
                                                    <input type="hidden" name="email" value="{{$farmer->email}}">
                                                    <button  class="btn btn-danger">Delete</button>
                                               </form>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               {{-- end modal --}}

                                    <div class="">
                                        {{-- start modal --}}

                                                <form  action="{{url('dashboard-updateinfo')}}" method="POST" enctype="multipart/form-data">
                                                    @csrf
                                                    <!-- Modal -->
                                                    <div class="modal fade" id="addfarmer{{$loop->index}}" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                        <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                            <h5 class="modal-title" id="staticBackdropLabel">Farmers Form</h5>
                                                            <button  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">

                                                                <div class="mb-3">
                                                                    <label for="email" class="form-label">Email</label>
                                                                    <input disabled value="{{$info->user_id}}" type="email" class="form-control" id="email" placeholder="Type email..">
                                                                    <input type="hidden" name="email" value="{{$info->user_id}}">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="firstname" class="form-label">FirstName</label>
                                                                    <input  value="{{$info->firstname}}" type="text" class="form-control" id="firstname" name="firstname" placeholder="Type first name..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="middlename" class="form-label">MiddleName</label>
                                                                    <input  value="{{$info->middlename}}" type="text" class="form-control" id="middlename" name="middlename" placeholder="Type middle name..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="lastname" class="form-label">LastName</label>
                                                                    <input  value="{{$info->lasatname}}" type="text" class="form-control" id="lastname" name="lastname" placeholder="Type last name..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="age" class="form-label">Age</label>
                                                                    <input  value="{{$info->age}}" type="text" class="form-control" id="age" name="age" placeholder="Type age..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="gender" class="form-label">Gender</label>
                                                                    <input  value="{{$info->gender}}" type="text" class="form-control" id="gender" name="gender" placeholder="Type gender..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="birthday" class="form-label">Birthday</label>
                                                                    <input  value="{{$info->birthday}}" type="text" class="form-control" id="birthday" name="birthday" placeholder="Type birthday..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="address" class="form-label">Address</label>
                                                                    <input  value="{{$info->address}}" type="text" class="form-control" id="address" name="address" placeholder="Type address..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="rsbsa" class="form-label">RSBSA</label>
                                                                    <input  value="{{$info->rsbsa}}" type="text" class="form-control" id="rsbsa" name="rsbsa" placeholder="Type RSBSA..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="contacts" class="form-label">Contacts</label>
                                                                    <input  value="{{$info->contacts}}" type="text" class="form-control" id="contacts" name="contacts" placeholder="Type contacts..">
                                                                </div>

                                                            </div>
                                                            <div class="modal-footer">
                                                                <button  class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                                                                <input type="submit" class="btn btn-outline-success" value="Save"/>
                                                            </div>
                                                        </div>
                                                        </div>
                                                    </div>
                                                </form>
                                                {{-- end modal --}}
                                            </div>



                            @endif
                            @endforeach

                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </ul>

{{-- Reports --}}
      <ul class="mt-3 overflow-hidden list-group">
        <li class="justify-between list-group-item bg-success d-flex" aria-current="true">
           <b class="text-white"> Reports</b>
           {{-- <a href=""  data-bs-toggle="modal" data-bs-target="#dontt"><i class="fa fas fa-solid fa-plus"></i></a> --}}
        </li>

        <div class="overflow-auto">
            <table class="table table-striped table-success table-hover">
                <thead>
                    <th>#</th>
                    <th>Type of Crop</th>
                    <th>Estimated Losses</th>
                    <th>Hectares</th>
                    <th>Disaster</th>
                    <th>Date of Disaster</th>
                    <th>Images</th>
                </thead>
                <tbody>

                    @php
                        $reports = App\Models\Report::all();
                        $counting = 1;
                    @endphp
                    @foreach ($reports as $report)
                        <tr>
                            <td>{{$loop->index+1}}</td>
                            <td>{{$report->crop}}</td>
                            <td>{{$report->losses}}</td>
                            <td>{{$report->hectare}}</td>
                            <td>{{$report->disaster}}</td>
                            <td>{{$report->date}}</td>
                            <td>
                                <button name="{{$loop->index}}"  class="btn btn-sm btn-primary w-100" data-bs-toggle="modal" data-bs-target="#okies{{$report->id}}">
                                    View
                                </button>

                            <!-- Modal -->
                            <div name="{{$loop->index}}" class="modal fade" id="okies{{$report->id}}"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog modal-xl">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                        <h5 class="modal-title" id="staticBackdropLabel">Pictures of damages</h5>
                                        <button  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="overflow-y-scroll modal-body">


                                                <div class="card" >
                                                    <div class="card-body d-flex ">
                                                        @php
                                                            $images = App\Models\Photo::all();

                                                        @endphp
                                                        @foreach ($images as $photo)
                                                            @if ($photo->report_id == $report->image_id)


                                                                <div class="d-flex d-inline-flex ">

                                                                    <img class="img-fluid img-thumbnail" src="{{asset('images').'/'.$photo->name}}" alt="">
                                                                </div>
                                                            @endif
                                                        @endforeach

                                                    </div>

                                                </div>

                                        </div>

                                        <div class="modal-footer">
                                            <button  class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {{-- end modal --}}

                            </td>
                        </tr>

                    @endforeach
                </tbody>
            </table>
        </div>
    </ul>


    {{-- Request --}}
    <ul class="mt-3 overflow-hidden list-group">
        <li class="justify-between list-group-item bg-success d-flex" aria-current="true">
           <b class="text-white"> Contact Request</b>
           {{-- <a href=""  data-bs-toggle="modal" data-bs-target="#dontt"><i class="fa fas fa-solid fa-plus"></i></a> --}}
        </li>

        <div class="overflow-auto">
            <table class="table table-striped table-success table-hover">
                <thead>
                    <th>#</th>
                    <th>Name</th>
                    <th>Message</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Date and Time</th>
                    <th>Delete</th>
                </thead>
                <tbody>

                    @php
                        $requests = App\Models\ContactRequest::all();

                    @endphp
                    @foreach ($requests as $report)
                        <tr>
                            <td>{{$loop->index +1}}</td>
                            <td>{{$report->name}}</td>
                            <td>{{$report->message}}</td>
                            <td>{{$report->email}}</td>
                            <td>{{$report->contact}}</td>
                            <td>{{$report->calldate}}  {{$report->calltime}}</td>

                            <td >

                                <button name="{{$loop->index}}"  class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#messagedelete{{$report->id}}">
                                    <i class="fa fas fa-solid fa-xmark"></i>
                                </button>
                            <!-- Modal -->
                            <div name="messagedelete{{$loop->index}}" class="modal fade" id="messagedelete{{$report->id}}"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                        <h5 class="modal-title" id="staticBackdropLabel">Delete Form</h5>
                                        <button  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="overflow-y-scroll modal-body">

                                            Want to delete this message request? Click <b>Cancel</b> to refuse..
                                        </div>

                                        <div class="modal-footer">
                                            <button  class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <form action="{{route('message-delete')}}"  method="GET" enctype="multipart/form-data">
                                                <input type="hidden" name="message" value="{{$report->id}}">
                                                <button  class="btn btn-danger">Delete</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {{-- end modal --}}

                            </td>
                        </tr>

                    @endforeach
                </tbody>
            </table>
        </div>
    </ul>


    <div class="">
        {{-- start modal --}}

            <form  action="{{url('dashboard-register')}}" method="POST" enctype="multipart/form-data">
                @csrf
                <!-- Modal -->
                <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">Damages Report Form</h5>
                        <button  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="crop" class="form-label">Type of Crop (Choose one only)</label>
                                <input required type="text" class="form-control" id="crop" name="crop" placeholder="Ex: Rice, Corn, Union, Banana etc.">
                            </div>

                            <div class="mb-3">
                                <label for="losses" class="form-label">Estimated Crop Losses</label>
                                <input required type="number" class="form-control" id="losses" name="losses" placeholder="Php 000.00">
                            </div>
                            <div class="mb-3">
                                <label for="hectare" class="form-label">Hectares</label>
                                <input required type="text" class="form-control" id="hectare" name="hectare" placeholder="Input Hectares">
                            </div>

                            <div class="mb-3">
                                <label for="disaster" class="form-label">Type of Disaster</label>
                                <input required type="text" class="form-control" id="disaster" name="disaster" placeholder="Ex: Flood, High Wind, Typhoon">
                            </div>

                            <div class="mb-3">
                                <label for="dated" class="form-label">Date</label>
                                <input required type="text" class="form-control" id="dated" name="dated" placeholder="Date of typhoon">
                            </div>

                            <div class="mb-3">
                                <label for="pic" class="form-label">Picture of Damages</label>
                                <input type="file" name="photos" class="form-control" id="pic">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button  class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <input type="submit" class="btn btn-outline-success" value="Add"/>
                        </div>
                    </div>
                    </div>
                </div>
            </form>
            {{-- end modal --}}
        </div>


    </x-app-layout>
