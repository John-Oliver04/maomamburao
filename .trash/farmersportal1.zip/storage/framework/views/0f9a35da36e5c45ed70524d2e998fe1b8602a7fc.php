<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
       <!-- Fonts -->
       <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

       <!-- CSS only -->
       <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
       <!-- JavaScript Bundle with Popper -->
       <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
        <!-- Google WebFonts -->
       <link rel="preconnect" href="https://fonts.gstatic.com">
       <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">
       <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" integrity="sha384-xeJqLiuOvjUBq3iGOjvSQSIlwrpqjSHXpduPd6rQpuiM3f5/ijby8pCsnbu5S81n" crossorigin="anonymous">

       <!-- Icon Font Stylesheet -->
       <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">
       <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/fontawesome.min.css" integrity="sha512-giQeaPns4lQTBMRpOOHsYnGw1tGVzbAIHUyHRgn7+6FmiEgGGjaG0T2LZJmAPMzRCl+Cug0ItQ2xDZpTmEc+CQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
       <!-- Styles -->
       <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

       <!-- Scripts -->
       <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
       <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>



</head>
<body>

    <div class="">

        <div class="text-center d-flex justify-content-center">
            <div class="justify-around d-flex">
                 <p></p><img width="100px" src="<?php echo e(asset('logo1.png')); ?>" alt=""><p></p>
            </div>


        </div>
        <div class="text-center row">

               <p>Republic of the Phiippines</p>  <br>
               <p> Mamburao Occidental Mindoro</p> <br>
               <p>MUNICIPALITY OF MAMBURAO</p>  <br>
                                            <br>
               <b class="h3">Municipal Agriculture office</b>
        </div>
    </div>


    <hr class="my-5">


    <ul class="mt-3 overflow-hidden list-group">
        <li class="justify-between list-group-item bg-success d-flex" aria-current="true">
           <b class="text-white"> Farmers</b>
         </li>
        <div   >
            <table class="table table-striped table-hover">
                <thead>
                    <th>email</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Birthday</th>
                    <th>Address</th>
                    <th>RSBSA</th>
                    <th>Contacts</th>
                </thead>
                <tbody>
                    <?php
                        $countfarmers = Auth::user()->whereRoleIs('farmer')->get();
                        $countinfos = App\Models\Info::all();
                    ?>

                    <?php $__currentLoopData = $countfarmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farmer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php $__currentLoopData = $countinfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($farmer->email == $info->user_id): ?>

                                    <td><?php echo e($farmer->email); ?></td>
                                    <td>
                                        FirstName:  <?php echo e($info->firstname); ?> <br>
                                        MiddleName: <?php echo e($info->middlename); ?> <br>
                                        LastName: <?php echo e($info->lastname); ?>

                                    </td>
                                    <td><?php echo e($info->age); ?></td>
                                    <td><?php echo e($info->gender); ?></td>
                                    <td><?php echo e($info->birthday); ?></td>
                                    <td><?php echo e($info->address); ?></td>
                                    <td><?php echo e($info->rsbsa); ?></td>
                                    <td><?php echo e($info->contacts); ?></td>



                                   <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </ul>



    <div class="">
        <ul class="mt-3 overflow-hidden  list-group">
            <li class="justify-between list-group-item bg-success d-flex" aria-current="true">
               <b class="text-white"> Reports</b>
             </li>

            
            <table class="table table-hover table-striped">
                <thead>
                    <th>#</th>
                    <th>Crop</th>
                    <th>Estimated Losses</th>
                    <th>Disaster</th>
                    <th>Date</th>
                    <th>Email</th>
                </thead>
                <tbody>
                    <?php
                        $damagedetails = App\Models\Report::all();
                    ?>
                    <?php $__currentLoopData = $damagedetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $damage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index +1); ?></td>
                        <td><?php echo e($damage->crop); ?></td>
                        <td><?php echo e($damage->losses); ?></td>
                        <td><?php echo e($damage->hectare); ?></td>
                        <td><?php echo e($damage->disaster); ?></td>
                        <td><?php echo e($damage->date); ?></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </ul>
    </div>


</body>
</html>

<?php /**PATH C:\Users\admin\Documents\laravel\farmerportal\resources\views/admin/print/alldetails.blade.php ENDPATH**/ ?>