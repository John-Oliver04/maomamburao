<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    You're logged in as Admin!
                </div>
            </div>
        </div>
    </div>

    <ul class="mt-3 overflow-hidden list-group">
        <li class="justify-between list-group-item bg-success d-flex" aria-current="true">
           <b class="text-white"> Farmers</b>
           
        </li>
        <div class="overflow-auto">
            <table class="table table-striped table-success table-hover">
                <thead>
                    <th>email</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Birthday</th>
                    <th>Address</th>
                    <th>RSBSA</th>
                    <th>Contacts</th>
                    <th>Action</th>
                </thead>
                <tbody>
                    <?php
                        $countfarmers = Auth::user()->whereRoleIs('farmer')->get();
                        $countinfos = App\Models\Info::all();
                    ?>

                    <?php $__currentLoopData = $countfarmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farmer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php $__currentLoopData = $countinfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($farmer->email == $info->user_id): ?>
                                <td><?php echo e($farmer->email); ?></td>
                                <td>
                                    FirstName:  <?php echo e($info->firstname); ?> <br>
                                    MiddleName: <?php echo e($info->middlename); ?> <br>
                                    LastName: <?php echo e($info->lastname); ?>

                                </td>
                                <td><?php echo e($info->age); ?></td>
                                <td><?php echo e($info->gender); ?></td>
                                <td><?php echo e($info->birthday); ?></td>
                                <td><?php echo e($info->address); ?></td>
                                <td><?php echo e($info->rsbsa); ?></td>
                                <td><?php echo e($info->contacts); ?></td>
                                <td>

                                    <!--  single primary button -->
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-warning dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                        Action
                                        </button>
                                        <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#addfarmer<?php echo e($loop->index); ?>" href="#">Edit</a></li>
                                        <li>
                                            <form action="<?php echo e(route('generate-report-farmer')); ?>" target="_blank" method="GET" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <input class="dropdown-item" type="submit" value="Preview">
                                                <input type="hidden" name="$emailna" value="<?php echo e($farmer->email); ?>">
                                            </form>
                                        </li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li>
                                                <!-- Button trigger modal -->


                                                <a href="#" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#deleted<?php echo e($loop->index); ?>">
                                                    Delete
                                                </a>

                                            </li>
                                        </ul>
                                    </div>
                                </td>


                                <!-- Modal -->
                               <div name="deleted<?php echo e($loop->index); ?>" class="modal fade" id="deleted<?php echo e($loop->index); ?>"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                   <div class="modal-dialog">
                                       <div class="modal-content">
                                           <div class="modal-header">
                                           <h5 class="modal-title" id="staticBackdropLabel">Delete form</h5>
                                           <button  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                           </div>
                                           <div class="overflow-y-scroll modal-body">
                                                Do you want to delete this selected data? Click <b>Cancel</b> to refuse..

                                           </div>

                                           <div class="modal-footer">
                                               <button  class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                               <form action="<?php echo e(route('farmer-delete')); ?>"  method="GET" enctype="multipart/form-data">
                                                    <input type="hidden" name="email" value="<?php echo e($farmer->email); ?>">
                                                    <button  class="btn btn-danger">Delete</button>
                                               </form>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               

                                    <div class="">
                                        

                                                <form  action="<?php echo e(url('dashboard-updateinfo')); ?>" method="POST" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <!-- Modal -->
                                                    <div class="modal fade" id="addfarmer<?php echo e($loop->index); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                        <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                            <h5 class="modal-title" id="staticBackdropLabel">Farmers Form</h5>
                                                            <button  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">

                                                                <div class="mb-3">
                                                                    <label for="email" class="form-label">Email</label>
                                                                    <input disabled value="<?php echo e($info->user_id); ?>" type="email" class="form-control" id="email" placeholder="Type email..">
                                                                    <input type="hidden" name="email" value="<?php echo e($info->user_id); ?>">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="firstname" class="form-label">FirstName</label>
                                                                    <input  value="<?php echo e($info->firstname); ?>" type="text" class="form-control" id="firstname" name="firstname" placeholder="Type first name..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="middlename" class="form-label">MiddleName</label>
                                                                    <input  value="<?php echo e($info->middlename); ?>" type="text" class="form-control" id="middlename" name="middlename" placeholder="Type middle name..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="lastname" class="form-label">LastName</label>
                                                                    <input  value="<?php echo e($info->lasatname); ?>" type="text" class="form-control" id="lastname" name="lastname" placeholder="Type last name..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="age" class="form-label">Age</label>
                                                                    <input  value="<?php echo e($info->age); ?>" type="text" class="form-control" id="age" name="age" placeholder="Type age..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="gender" class="form-label">Gender</label>
                                                                    <input  value="<?php echo e($info->gender); ?>" type="text" class="form-control" id="gender" name="gender" placeholder="Type gender..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="birthday" class="form-label">Birthday</label>
                                                                    <input  value="<?php echo e($info->birthday); ?>" type="text" class="form-control" id="birthday" name="birthday" placeholder="Type birthday..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="address" class="form-label">Address</label>
                                                                    <input  value="<?php echo e($info->address); ?>" type="text" class="form-control" id="address" name="address" placeholder="Type address..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="rsbsa" class="form-label">RSBSA</label>
                                                                    <input  value="<?php echo e($info->rsbsa); ?>" type="text" class="form-control" id="rsbsa" name="rsbsa" placeholder="Type RSBSA..">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="contacts" class="form-label">Contacts</label>
                                                                    <input  value="<?php echo e($info->contacts); ?>" type="text" class="form-control" id="contacts" name="contacts" placeholder="Type contacts..">
                                                                </div>

                                                            </div>
                                                            <div class="modal-footer">
                                                                <button  class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                                                                <input type="submit" class="btn btn-outline-success" value="Save"/>
                                                            </div>
                                                        </div>
                                                        </div>
                                                    </div>
                                                </form>
                                                
                                            </div>



                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </ul>


      <ul class="mt-3 overflow-hidden list-group">
        <li class="justify-between list-group-item bg-success d-flex" aria-current="true">
           <b class="text-white"> Reports</b>
           
        </li>

        <div class="overflow-auto">
            <table class="table table-striped table-success table-hover">
                <thead>
                    <th>#</th>
                    <th>Type of Crop</th>
                    <th>Estimated Losses</th>
                    <th>Hectares</th>
                    <th>Disaster</th>
                    <th>Date of Disaster</th>
                    <th>Images</th>
                </thead>
                <tbody>

                    <?php
                        $reports = App\Models\Report::all();
                        $counting = 1;
                    ?>
                    <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td><?php echo e($report->crop); ?></td>
                            <td><?php echo e($report->losses); ?></td>
                            <td><?php echo e($report->hectare); ?></td>
                            <td><?php echo e($report->disaster); ?></td>
                            <td><?php echo e($report->date); ?></td>
                            <td>
                                <button name="<?php echo e($loop->index); ?>"  class="btn btn-sm btn-primary w-100" data-bs-toggle="modal" data-bs-target="#okies<?php echo e($report->id); ?>">
                                    View
                                </button>

                            <!-- Modal -->
                            <div name="<?php echo e($loop->index); ?>" class="modal fade" id="okies<?php echo e($report->id); ?>"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog modal-xl">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                        <h5 class="modal-title" id="staticBackdropLabel">Pictures of damages</h5>
                                        <button  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="overflow-y-scroll modal-body">


                                                <div class="card" >
                                                    <div class="card-body d-flex ">
                                                        <?php
                                                            $images = App\Models\Photo::all();

                                                        ?>
                                                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($photo->report_id == $report->image_id): ?>


                                                                <div class="d-flex d-inline-flex ">

                                                                    <img class="img-fluid img-thumbnail" src="<?php echo e(asset('images').'/'.$photo->name); ?>" alt="">
                                                                </div>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </div>

                                                </div>

                                        </div>

                                        <div class="modal-footer">
                                            <button  class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            

                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </ul>


    
    <ul class="mt-3 overflow-hidden list-group">
        <li class="justify-between list-group-item bg-success d-flex" aria-current="true">
           <b class="text-white"> Contact Request</b>
           
        </li>

        <div class="overflow-auto">
            <table class="table table-striped table-success table-hover">
                <thead>
                    <th>#</th>
                    <th>Name</th>
                    <th>Message</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Date and Time</th>
                    <th>Delete</th>
                </thead>
                <tbody>

                    <?php
                        $requests = App\Models\ContactRequest::all();

                    ?>
                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index +1); ?></td>
                            <td><?php echo e($report->name); ?></td>
                            <td><?php echo e($report->message); ?></td>
                            <td><?php echo e($report->email); ?></td>
                            <td><?php echo e($report->contact); ?></td>
                            <td><?php echo e($report->calldate); ?>  <?php echo e($report->calltime); ?></td>

                            <td >

                                <button name="<?php echo e($loop->index); ?>"  class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#messagedelete<?php echo e($report->id); ?>">
                                    <i class="fa fas fa-solid fa-xmark"></i>
                                </button>
                            <!-- Modal -->
                            <div name="messagedelete<?php echo e($loop->index); ?>" class="modal fade" id="messagedelete<?php echo e($report->id); ?>"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                        <h5 class="modal-title" id="staticBackdropLabel">Delete Form</h5>
                                        <button  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="overflow-y-scroll modal-body">

                                            Want to delete this message request? Click <b>Cancel</b> to refuse..
                                        </div>

                                        <div class="modal-footer">
                                            <button  class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <form action="<?php echo e(route('message-delete')); ?>"  method="GET" enctype="multipart/form-data">
                                                <input type="hidden" name="message" value="<?php echo e($report->id); ?>">
                                                <button  class="btn btn-danger">Delete</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            

                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </ul>


    <div class="">
        

            <form  action="<?php echo e(url('dashboard-register')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <!-- Modal -->
                <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">Damages Report Form</h5>
                        <button  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="crop" class="form-label">Type of Crop (Choose one only)</label>
                                <input required type="text" class="form-control" id="crop" name="crop" placeholder="Ex: Rice, Corn, Union, Banana etc.">
                            </div>

                            <div class="mb-3">
                                <label for="losses" class="form-label">Estimated Crop Losses</label>
                                <input required type="number" class="form-control" id="losses" name="losses" placeholder="Php 000.00">
                            </div>
                            <div class="mb-3">
                                <label for="hectare" class="form-label">Hectares</label>
                                <input required type="text" class="form-control" id="hectare" name="hectare" placeholder="Input Hectares">
                            </div>

                            <div class="mb-3">
                                <label for="disaster" class="form-label">Type of Disaster</label>
                                <input required type="text" class="form-control" id="disaster" name="disaster" placeholder="Ex: Flood, High Wind, Typhoon">
                            </div>

                            <div class="mb-3">
                                <label for="dated" class="form-label">Date</label>
                                <input required type="text" class="form-control" id="dated" name="dated" placeholder="Date of typhoon">
                            </div>

                            <div class="mb-3">
                                <label for="pic" class="form-label">Picture of Damages</label>
                                <input type="file" name="photos" class="form-control" id="pic">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button  class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <input type="submit" class="btn btn-outline-success" value="Add"/>
                        </div>
                    </div>
                    </div>
                </div>
            </form>
            
        </div>


     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\admin\Documents\laravel\farmerportal\resources\views/admindashboard.blade.php ENDPATH**/ ?>