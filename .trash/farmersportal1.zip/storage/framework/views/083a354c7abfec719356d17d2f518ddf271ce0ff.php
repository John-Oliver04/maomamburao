<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    You're logged in as Farmer!
                </div>
            </div>
        </div>
    </div>

    <?php
        $infos = App\Models\Info::all();
    ?>
    <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($info->user_id == Auth::user()->email): ?>
            <ul class="list-group">

                <li class="justify-between list-group-item bg-success d-flex" aria-current="true">
                <b class="text-white"> Personal Information</b>
                <button onclick="enabletext()" ><i class="fa fas fa-regular fa-pen-to-square"></i></button>
                </li>
                <div id="disabledtext">
                    <li class="list-group-item"><b>FirstName: </b> <input value="<?php echo e($info->firstname); ?>" disabled placeholder="Enter firstname.." class="border-0" type="text" name="" id=""></li>
                    <li class="list-group-item"><b>MiddleName: </b><input value="<?php echo e($info->middlename); ?>" disabled placeholder="Enter middlename.." class="border-0" type="text" name="middename" id=""> </li>
                    <li class="list-group-item"><b>LastName: </b> <input value="<?php echo e($info->lastname); ?>" disabled  placeholder="Enter lastname.." class="border-0" type="text" name="" id=""></li>
                    <li class="list-group-item"><b>Age: </b> <input value="<?php echo e($info->age); ?>" disabled placeholder="Enter age.." class="border-0" type="text" name="" id=""></li>
                    <li class="list-group-item"><b>Gender: </b> <input value="<?php echo e($info->gender); ?>" disabled placeholder="Enter gender.." class="border-0" type="text" name="" id=""></li>
                    <li class="list-group-item"><b>Birthday: </b> <input value="<?php echo e($info->birthday); ?>" disabled placeholder="Enter birthday.." class="border-0" type="text" name="" id=""></li>
                    <li class="list-group-item"><b>Address: </b> <input value="<?php echo e($info->address); ?>" disabled placeholder="Enter address.." class="border-0" type="text" name="" id=""></li>
                    <li class="list-group-item"><b>RSBSA: </b><input value="<?php echo e($info->rsbsa); ?>" disabled placeholder="Enter RSBSA.." class="border-0" type="text" name="" id=""> </li>
                    <li class="list-group-item"><b>Contacts: </b><input value="<?php echo e($info->contacts); ?>" disabled placeholder="Enter contact number.." class="border-0" type="text" name="" id=""> </li>
                    <li class="text-right list-group-item"><button disabled class="btn btn-success btn-sm">Save</button></li>
                </div>
                <form  action="<?php echo e(url('dashboard-updateinfo')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div id="enabledtext" style="display: none;">
                        <li class="list-group-item"><b>FirstName:</b><input  value="<?php echo e($info->firstname); ?>"  placeholder="Enter firstname.." class="form-control" type="text" name="firstname" id=""></li>
                        <li class="list-group-item"><b>MiddleName:</b><input value="<?php echo e($info->middlename); ?>"  placeholder="Enter middlename.." class="form-control" type="text" name="middlename" id=""> </li>
                        <li class="list-group-item"><b>LastName:</b><input  value="<?php echo e($info->lastname); ?>"  placeholder="Enter lastname.." class="form-control" type="text" name="lastname" id=""></li>
                        <li class="list-group-item">
                            <b>Age:</b>
                                <select name="age" class="form-control" id="age">

                                      <?php for($x =18; $x <= 100; $x++): ?>
                                         <option value="<?php echo e($x); ?>"><?php echo e($x); ?></option>
                                      <?php endfor; ?>

                                </select>

                        </li>
                        <li class="list-group-item">
                            <b>Gender:</b>
                            <select name="gender" class="form-control" id="gender">
                                <option value="Male">Male</option>
                               <option value="Female">Female</option>
                            </select>
                        </li>
                        <li class="list-group-item"><b>Birthday:</b><input value="<?php echo e($info->birthday); ?>"  placeholder="Enter birthday.." class="form-control" type="date" name="birthday" id=""></li>
                        <li class="list-group-item"><b>Address:</b><input  value="<?php echo e($info->address); ?>" placeholder="Enter address.." class="form-control" type="text" name="address" id=""></li>
                        <li class="list-group-item"><b>RSBSA:</b><input  value="<?php echo e($info->rsbsa); ?>" placeholder="Enter RSBSA.." class="form-control" type="text" name="rsbsa" id=""> </li>
                        <li class="list-group-item"><b>Contacts:</b><input value="<?php echo e($info->contacts); ?>" placeholder="Enter contact number.." class="form-control" type="text" name="contacts" id=""> </li>
                        <input type="hidden" name="email" value="<?php echo e(Auth::user()->email); ?>">
                        <li class="text-right list-group-item"><input type="submit"  class="btn btn-success btn-sm" value="Save"/></li>
                    </div>
                </form>
            </ul>

        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


      <ul class="mt-3 overflow-hidden list-group">
        <li class="justify-between list-group-item bg-success d-flex" aria-current="true">
           <b class="text-white"> Reports</b>
           <a href=""  data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class="fa fas fa-solid fa-plus"></i></a>
        </li>

        <div class="overflow-auto">
            <table class="table table-striped table-success table-hover">
                <thead>
                    <th>Type of Crop</th>
                    <th>Estimated Losses</th>
                    <th>Hectares</th>
                    <th>Disaster</th>
                    <th>Date of Disaster</th>
                    <th>Images</th>
                </thead>
                <tbody>

                    <?php
                        $reports = App\Models\Report::all();
                        $counting = 1;
                    ?>
                    <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($report->email == Auth::user()->id): ?>
                        <tr>
                            <td><?php echo e($report->crop); ?></td>
                            <td><?php echo e($report->losses); ?></td>
                            <td><?php echo e($report->hectare); ?></td>
                            <td><?php echo e($report->disaster); ?></td>
                            <td><?php echo e($report->date); ?></td>
                            <td>
                                <button name="<?php echo e($loop->index); ?>"  class="btn btn-sm btn-success w-100" data-bs-toggle="modal" data-bs-target="#okies<?php echo e($report->id); ?>">
                                    View
                                </button>

                            <!-- Modal -->
                            <div name="<?php echo e($loop->index); ?>" class="modal fade" id="okies<?php echo e($report->id); ?>"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog modal-xl">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                        <h5 class="modal-title" id="staticBackdropLabel">Pictures of damages</h5>
                                        <button  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="overflow-y-scroll modal-body">


                                                <div class="card" >
                                                    <div class="card-body d-flex ">
                                                        <?php
                                                            $images = App\Models\Photo::all();

                                                        ?>
                                                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($photo->report_id == $report->image_id): ?>


                                                                <div class="d-flex d-inline-flex ">

                                                                    <img class="img-fluid img-thumbnail" src="<?php echo e(asset('images').'/'.$photo->name); ?>" alt="">
                                                                </div>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </div>

                                                </div>

                                        </div>
                                        <div class=" card-footer">
                                            <form  action="<?php echo e(route('dashboard-addimage')); ?>" method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="hiddenid" value="<?php echo e($report->image_id); ?>">

                                                <label for="pic" class="form-label">Add Image</label>
                                                <input type="file" required name="photos" class="form-control" id="photos">

                                                <input type="submit" class="mt-3 text-white btn bg-success w-100" value="Add"/>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button  class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            

                            </td>
                            <td>
                                <button name="<?php echo e($loop->index); ?>"  class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#reportdelete<?php echo e($report->id); ?>">
                                    <i class="fa fas fa-solid fa-xmark"></i>
                                </button>
                                <!-- Modal -->
                                <div name="reportdelete<?php echo e($report->id); ?>" class="modal fade" id="reportdelete<?php echo e($report->id); ?>"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                            <h5 class="modal-title" id="staticBackdropLabel">Delete Form</h5>
                                            <button  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="overflow-y-scroll modal-body">

                                                Want to delete this current report? Click <b>Cancel</b> to refuse..
                                            </div>

                                            <div class="modal-footer">
                                                <button  class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <form action="<?php echo e(route('report-delete')); ?>"  method="GET" enctype="multipart/form-data">
                                                    <input type="hidden" name="report" value="<?php echo e($report->id); ?>">
                                                    <button  class="btn btn-danger">Delete</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </td>
                        </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </ul>

    <div class="">
        

            <form  action="<?php echo e(url('dashboard-register')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <!-- Modal -->
                <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">Damages Report Form</h5>
                        <button  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="crop" class="form-label">Type of Crop (Choose one only)</label>
                                <select  name="crop" class="form-control" id="crop">
                                    <option value="Rice">Rice</option>
                                    <option value="Corn">Corn</option>
                                    <option value="Union">Union</option>
                                    <option value="Banana">Banana</option>
                                    <option value="Cassava">Cassava</option>
                                </select>
                            </div>


                            <div class="mb-3">
                                <label for="losses" class="form-label">Estimated Crop Losses</label>
                                <select  name="losses" class="form-control" id="losses">
                                    <?php for($l = 5000; $l <= 200000; $l=$l+5000): ?>
                                        <option value="Php <?php echo e($l); ?>">Php <?php echo e($l); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="hectare" class="form-label">Hectares</label>
                                <select  name="hectare" class="form-control" id="hectare">
                                    <?php for($h = 1; $h <= 10; $h++): ?>
                                        <option value="<?php echo e($h); ?> hectare"><?php echo e($h); ?> hectare</option>
                                    <?php endfor; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="disaster" class="form-label">Type of Disaster</label>
                                <select  name="disaster" class="form-control" id="disaster">
                                    <option value="Rice">Flood</option>
                                    <option value="Corn">Drought</option>
                                    <option value="Union">Typhoon</option>
                                    <option value="Union">Typhoon w/ high winds</option>
                                    <option value="Banana">Landslides</option>
                                    <option value="Cassava">Wildfires</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="dated" class="form-label">Date</label>
                                <input required type="date" class="form-control" id="dated" name="dated" placeholder="Date of typhoon">
                            </div>

                            <div class="mb-3">
                                <label for="pic" class="form-label">Picture of Damages</label>
                                <input type="file" name="photos" class="form-control" id="pic">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button  class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <input type="submit" class="btn btn-outline-success" value="Add"/>
                        </div>
                    </div>
                    </div>
                </div>
            </form>
            
        </div>


     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/u491758168/domains/maomamburao.com/resources/views/farmerdashboard.blade.php ENDPATH**/ ?>