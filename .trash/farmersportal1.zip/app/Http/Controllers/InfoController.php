<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\Info;
use App\Models\User;
use App\Models\Report;
use App\Models\Photo;
use App\Models\ContactRequest;


class InfoController extends Controller
{
    public function editinfo(Request $request)
    {


            Info::where('user_id', $request->input('email'))->update(
                [
                    'firstname' => $request->input('firstname'),
                    'middlename' => $request->input('middlename'),
                    'lastname' => $request->input('lastname'),
                    'age' => $request->input('age'),
                    'gender' => $request->input('gender'),
                    'birthday' => $request->input('birthday'),
                    'address' => $request->input('address'),
                    'rsbsa' => $request->input('rsbsa'),
                    'contacts' => $request->input('contacts'),

                ]
            );

            return redirect()->back()->with('success','Successfully updated!');
    }


    public function show(Request $request)
    {

        $email = $request->query('$emailna');
// dd($email);
        $person = Info::where('user_id','=',$email)->get();
        return view('admin.print.persondetails')->with('person',$person);
    }

    public function delete(Request $request)
    {

        $email = $request->query('email');

        $users = User::where('email',$email)->get();
        $reports = User::all();
        foreach ($users as $user) {
            foreach ($reports as $report) {
                if ($user->id == $report->email) {
                    Photo::where('report_id',$report->image_id)->delete();
                    Report::where('email',$user->id)->delete();
                }
            }
        }
        Info::where('user_id',$email)->delete();
        User::where('email',$email)->delete();

       return redirect()->back()->with('success','Successfully deleted!');
    }


    public function messagedelete(Request $request)
    {

        $id = $request->query('message');
        ContactRequest::where('id',$id)->delete();

       return redirect()->back()->with('success','Successfully deleted!');
    }
    public function reportdelete(Request $request)
    {

        $id = $request->query('report');
        Report::where('id',$id)->delete();

       return redirect()->back()->with('success','Successfully deleted!');
    }




    // public function addfarmer(Request $request)
    // {
    //     if(Auth::user()->hasRole('admin')){



    //             Info::create(
    //                 [
    //                 'firstname' => $request->input('firstname'),
    //                 'middlename' => $request->input('middlename'),
    //                 'lastname' => $request->input('lastname'),
    //                 'age' => $request->input('age'),
    //                 'gender' => $request->input('gender'),
    //                 'birthday' => $request->input('birthday'),
    //                 'address' => $request->input('address'),
    //                 'rsbsa' => $request->input('rsbsa'),
    //                 'contacts' => $request->input('contacts'),
    //                 'user_id' => Auth::user()->email,
    //             ]
    //         );
    //         return redirect()->back()->with('success','Successfully Added to Damage Report!');

    //     }
    // }
}
